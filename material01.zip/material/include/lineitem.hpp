#pragma once

struct LineItem {
    // TODO 3.1: give each field its proper type
    int l_orderkey;
    int l_extendedprice;
    int l_discount;
    int l_returnflag;
};
